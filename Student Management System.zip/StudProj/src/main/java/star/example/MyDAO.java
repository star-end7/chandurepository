package star.example;

import org.springframework.data.repository.CrudRepository;
import star.example.StudRegPage;

public interface MyDAO extends CrudRepository<StudRegPage, String>{

}
