package star.example;

import org.springframework.data.repository.CrudRepository;

import star.example.StudRegPage;

public interface LoginDAO extends CrudRepository<StudRegPage, String>{

}
